﻿
namespace WF_QuanLyXeBus.GUI.Add_GUI
{
    partial class frmAddTuyenXe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTenTuyen = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbMaDV = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtLuotDi = new System.Windows.Forms.TextBox();
            this.txtLuotVe = new System.Windows.Forms.TextBox();
            this.cmbLoaiTuyen = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.mskTgKetThuc = new System.Windows.Forms.MaskedTextBox();
            this.mskTgBatDau = new System.Windows.Forms.MaskedTextBox();
            this.mskTgGianCach = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // txtTenTuyen
            // 
            this.txtTenTuyen.Location = new System.Drawing.Point(702, 23);
            this.txtTenTuyen.Multiline = true;
            this.txtTenTuyen.Name = "txtTenTuyen";
            this.txtTenTuyen.Size = new System.Drawing.Size(191, 26);
            this.txtTenTuyen.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(70, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã Đơn Vị:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(550, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên Tuyến:";
            // 
            // cmbMaDV
            // 
            this.cmbMaDV.FormattingEnabled = true;
            this.cmbMaDV.Location = new System.Drawing.Point(222, 23);
            this.cmbMaDV.Name = "cmbMaDV";
            this.cmbMaDV.Size = new System.Drawing.Size(145, 24);
            this.cmbMaDV.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(69, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "Thời gian Bắt Đầu:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(550, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(220, 26);
            this.label4.TabIndex = 5;
            this.label4.Text = "Thời gian Kết Thúc:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(69, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(198, 26);
            this.label5.TabIndex = 8;
            this.label5.Text = "Lộ Trình Lượt Đi:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(550, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(202, 26);
            this.label6.TabIndex = 9;
            this.label6.Text = "Lộ Trình Lượt Về:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(69, 421);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 26);
            this.label7.TabIndex = 10;
            this.label7.Text = "Loại Tuyến:";
            // 
            // txtLuotDi
            // 
            this.txtLuotDi.Location = new System.Drawing.Point(74, 223);
            this.txtLuotDi.Multiline = true;
            this.txtLuotDi.Name = "txtLuotDi";
            this.txtLuotDi.Size = new System.Drawing.Size(321, 170);
            this.txtLuotDi.TabIndex = 11;
            // 
            // txtLuotVe
            // 
            this.txtLuotVe.Location = new System.Drawing.Point(555, 223);
            this.txtLuotVe.Multiline = true;
            this.txtLuotVe.Name = "txtLuotVe";
            this.txtLuotVe.Size = new System.Drawing.Size(321, 170);
            this.txtLuotVe.TabIndex = 12;
            this.txtLuotVe.TextChanged += new System.EventHandler(this.txtLuotVe_TextChanged);
            // 
            // cmbLoaiTuyen
            // 
            this.cmbLoaiTuyen.FormattingEnabled = true;
            this.cmbLoaiTuyen.Items.AddRange(new object[] {
            "Trợ giá",
            "Không trợ giá"});
            this.cmbLoaiTuyen.Location = new System.Drawing.Point(210, 425);
            this.cmbLoaiTuyen.Name = "cmbLoaiTuyen";
            this.cmbLoaiTuyen.Size = new System.Drawing.Size(106, 24);
            this.cmbLoaiTuyen.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(85, 469);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(789, 5);
            this.panel1.TabIndex = 14;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.Location = new System.Drawing.Point(188, 509);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 38);
            this.button1.TabIndex = 15;
            this.button1.Text = "Lưu";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.Location = new System.Drawing.Point(624, 509);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 38);
            this.button2.TabIndex = 16;
            this.button2.Text = "Hủy";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button3.Location = new System.Drawing.Point(417, 509);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 38);
            this.button3.TabIndex = 17;
            this.button3.Text = "Làm Mới";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(69, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 26);
            this.label9.TabIndex = 19;
            this.label9.Text = "Giãn Cách:";
            // 
            // mskTgKetThuc
            // 
            this.mskTgKetThuc.Location = new System.Drawing.Point(777, 84);
            this.mskTgKetThuc.Margin = new System.Windows.Forms.Padding(4);
            this.mskTgKetThuc.Mask = "00:00:00";
            this.mskTgKetThuc.Name = "mskTgKetThuc";
            this.mskTgKetThuc.Size = new System.Drawing.Size(69, 22);
            this.mskTgKetThuc.TabIndex = 32;
            // 
            // mskTgBatDau
            // 
            this.mskTgBatDau.Location = new System.Drawing.Point(281, 84);
            this.mskTgBatDau.Margin = new System.Windows.Forms.Padding(4);
            this.mskTgBatDau.Mask = "00:00:00";
            this.mskTgBatDau.Name = "mskTgBatDau";
            this.mskTgBatDau.Size = new System.Drawing.Size(86, 22);
            this.mskTgBatDau.TabIndex = 33;
            // 
            // mskTgGianCach
            // 
            this.mskTgGianCach.Location = new System.Drawing.Point(210, 144);
            this.mskTgGianCach.Margin = new System.Windows.Forms.Padding(4);
            this.mskTgGianCach.Mask = "00 phút";
            this.mskTgGianCach.Name = "mskTgGianCach";
            this.mskTgGianCach.Size = new System.Drawing.Size(77, 22);
            this.mskTgGianCach.TabIndex = 34;
            // 
            // frmAddTuyenXe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(943, 590);
            this.Controls.Add(this.mskTgGianCach);
            this.Controls.Add(this.mskTgBatDau);
            this.Controls.Add(this.mskTgKetThuc);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cmbLoaiTuyen);
            this.Controls.Add(this.txtLuotVe);
            this.Controls.Add(this.txtLuotDi);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbMaDV);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTenTuyen);
            this.MaximizeBox = false;
            this.Name = "frmAddTuyenXe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAddTuyenXe";
            this.Load += new System.EventHandler(this.frmAddTuyenXe_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTenTuyen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbMaDV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtLuotDi;
        private System.Windows.Forms.TextBox txtLuotVe;
        private System.Windows.Forms.ComboBox cmbLoaiTuyen;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox mskTgKetThuc;
        private System.Windows.Forms.MaskedTextBox mskTgBatDau;
        private System.Windows.Forms.MaskedTextBox mskTgGianCach;
    }
}